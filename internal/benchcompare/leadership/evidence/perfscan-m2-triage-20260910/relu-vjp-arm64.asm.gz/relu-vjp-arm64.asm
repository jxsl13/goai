TEXT github.com/jxsl13/goai/autograd.reluVJP(SB) /private/tmp/goai-m2-f64-gelu-neon-26BhJN/repo/autograd/vjp_elementwise.go
  vjp_elementwise.go:112	0x1001e1f80		f9400b90		MOVD 16(R28), R16						
  vjp_elementwise.go:112	0x1001e1f84		d10083f1		SUB $32, RSP, R17						
  vjp_elementwise.go:112	0x1001e1f88		eb10023f		CMP R16, R17							
  vjp_elementwise.go:112	0x1001e1f8c		54002809		BLS 320(PC)							
  vjp_elementwise.go:112	0x1001e1f90		f8160ffe		MOVD.W R30, -160(RSP)						
  vjp_elementwise.go:112	0x1001e1f94		f81f83fd		MOVD R29, -8(RSP)						
  vjp_elementwise.go:112	0x1001e1f98		d10023fd		SUB $8, RSP, R29						
  vjp_elementwise.go:112	0x1001e1f9c		f9005be1		MOVD R1, 176(RSP)						
  vjp_elementwise.go:112	0x1001e1fa0		f90067e4		MOVD R4, 200(RSP)						
  vjp_elementwise.go:112	0x1001e1fa4		f90073e7		MOVD R7, 224(RSP)						
  vjp_elementwise.go:112	0x1001e1fa8		f90077e8		MOVD R8, 232(RSP)						
  vjp_elementwise.go:113	0x1001e1fac		b40026c2		CBZ R2, 310(PC)							
  vjp_elementwise.go:113	0x1001e1fb0		f9007be9		MOVD R9, 240(RSP)						
  vjp_elementwise.go:113	0x1001e1fb4		f90077e8		MOVD R8, 232(RSP)						
  vjp_elementwise.go:113	0x1001e1fb8		f90073e7		MOVD R7, 224(RSP)						
  vjp_elementwise.go:113	0x1001e1fbc		f9005be1		MOVD R1, 176(RSP)						
  vjp_elementwise.go:113	0x1001e1fc0		f9006fe6		MOVD R6, 216(RSP)						
  vjp_elementwise.go:113	0x1001e1fc4		f9006be5		MOVD R5, 208(RSP)						
  vjp_elementwise.go:113	0x1001e1fc8		f90067e4		MOVD R4, 200(RSP)						
  vjp_elementwise.go:113	0x1001e1fcc		f90063e3		MOVD R3, 192(RSP)						
  vjp_elementwise.go:113	0x1001e1fd0		f9005fe2		MOVD R2, 184(RSP)						
  vjp_elementwise.go:113	0x1001e1fd4		f9400026		MOVD (R1), R6							
  vjp_elementwise.go:113	0x1001e1fd8		f90037e6		MOVD R6, 104(RSP)						
  tensor.go:127			0x1001e1fdc		a9400cc7		LDP (R6), (R7, R3)						
  tensor.go:127			0x1001e1fe0		394000e2		MOVBU (R7), R2							
  tensor.go:130			0x1001e1fe4		a94114c4		LDP 16(R6), (R4, R5)						
  tensor.go:21			0x1001e1fe8		d0001e7b		ADRP 3989504(PC), R27						
  tensor.go:21			0x1001e1fec		9106c37b		ADD $432, R27, R27						
  tensor.go:21			0x1001e1ff0		a9400760		LDP (R27), (R0, R1)						
  vjp_elementwise.go:114	0x1001e1ff4		d503201f		NOOP								
  vjp_elementwise.go:114	0x1001e1ff8		d503201f		NOOP								
  vjp_elementwise.go:114	0x1001e1ffc		d503201f		NOOP								
  tensor.go:21			0x1001e2000		97fe74a0		CALL github.com/jxsl13/goai/tensor.NewOn(SB)			
  tensor.go:142			0x1001e2004		f94037e6		MOVD 104(RSP), R6						
  tensor.go:142			0x1001e2008		a940a0c7		LDP 8(R6), (R7, R8)						
  vjp_elementwise.go:115	0x1001e200c		d503201f		NOOP								
  shape.go:35			0x1001e2010		aa1f03e9		MOVD ZR, R9							
  shape.go:35			0x1001e2014		b24003ea		ORR $1, ZR, R10							
  shape.go:35			0x1001e2018		14000004		JMP 4(PC)							
  shape.go:35			0x1001e201c		f86978e1		MOVD (R7)(R9<<3), R1						
  shape.go:36			0x1001e2020		9b0a7c2a		MUL R10, R1, R10						
  shape.go:35			0x1001e2024		91000529		ADD $1, R9, R9							
  shape.go:35			0x1001e2028		eb08013f		CMP R8, R9							
  shape.go:35			0x1001e202c		54ffff8b		BLT -4(PC)							
  tensor.go:21			0x1001e2030		f9003be0		MOVD R0, 112(RSP)						
  shape.go:35			0x1001e2034		f9002fea		MOVD R10, 88(RSP)						
  vjp_elementwise.go:116	0x1001e2038		aa0603e0		MOVD R6, R0							
  vjp_elementwise.go:116	0x1001e203c		97fe77f1		CALL github.com/jxsl13/goai/tensor.(*Tensor).Contiguous(SB)	
  vjp_elementwise.go:116	0x1001e2040		f90033e0		MOVD R0, 96(RSP)						
  vjp_elementwise.go:116	0x1001e2044		f9407be0		MOVD 240(RSP), R0						
  vjp_elementwise.go:116	0x1001e2048		97fe77ee		CALL github.com/jxsl13/goai/tensor.(*Tensor).Contiguous(SB)	
  tensor.go:127			0x1001e204c		f94037e1		MOVD 104(RSP), R1						
  tensor.go:127			0x1001e2050		f9400021		MOVD (R1), R1							
  tensor.go:127			0x1001e2054		39400021		MOVBU (R1), R1							
  vjp_elementwise.go:117	0x1001e2058		d503201f		NOOP								
  vjp_elementwise.go:129	0x1001e205c		7100043f		CMPW $1, R1							
  vjp_elementwise.go:129	0x1001e2060		540002e1		BNE 23(PC)							
  tensor.go:127			0x1001e2064		f940000a		MOVD (R0), R10							
  tensor.go:127			0x1001e2068		3940014b		MOVBU (R10), R11						
  vjp_elementwise.go:130	0x1001e206c		7100057f		CMPW $1, R11							
  vjp_elementwise.go:130	0x1001e2070		54000561		BNE 43(PC)							
  tensor.go:121			0x1001e2074		f94033e5		MOVD 96(RSP), R5						
  tensor.go:121			0x1001e2078		f94000a5		MOVD (R5), R5							
  vjp_elementwise.go:131	0x1001e207c		d503201f		NOOP								
  vjp_elementwise.go:131	0x1001e2080		d503201f		NOOP								
  storage.go:114		0x1001e2084		a9411ca6		LDP 16(R5), (R6, R7)						
  storage.go:114		0x1001e2088		b4001d66		CBZ R6, 235(PC)							
  vjp_elementwise.go:131	0x1001e208c		d503201f		NOOP								
  storage.go:114		0x1001e2090		a9412145		LDP 16(R10), (R5, R8)						
  storage.go:114		0x1001e2094		b4001a85		CBZ R5, 212(PC)							
  tensor.go:121			0x1001e2098		f9403be9		MOVD 112(RSP), R9						
  tensor.go:121			0x1001e209c		f940012a		MOVD (R9), R10							
  vjp_elementwise.go:132	0x1001e20a0		d503201f		NOOP								
  vjp_elementwise.go:132	0x1001e20a4		d503201f		NOOP								
  storage.go:114		0x1001e20a8		a941314b		LDP 16(R10), (R11, R12)						
  storage.go:114		0x1001e20ac		b400174b		CBZ R11, 186(PC)						
  vjp_elementwise.go:133	0x1001e20b0		aa1f03e3		MOVD ZR, R3							
  vjp_elementwise.go:133	0x1001e20b4		f9402fe4		MOVD 88(RSP), R4						
  vjp_elementwise.go:133	0x1001e20b8		14000091		JMP 145(PC)							
  vjp_elementwise.go:118	0x1001e20bc		7100083f		CMPW $2, R1							
  vjp_elementwise.go:118	0x1001e20c0		540002e1		BNE 23(PC)							
  tensor.go:127			0x1001e20c4		f940000a		MOVD (R0), R10							
  tensor.go:127			0x1001e20c8		3940014b		MOVBU (R10), R11						
  vjp_elementwise.go:119	0x1001e20cc		7100097f		CMPW $2, R11							
  vjp_elementwise.go:119	0x1001e20d0		54000261		BNE 19(PC)							
  tensor.go:121			0x1001e20d4		f94033e5		MOVD 96(RSP), R5						
  tensor.go:121			0x1001e20d8		f94000a5		MOVD (R5), R5							
  vjp_elementwise.go:120	0x1001e20dc		d503201f		NOOP								
  vjp_elementwise.go:120	0x1001e20e0		d503201f		NOOP								
  storage.go:122		0x1001e20e4		a9429ca6		LDP 40(R5), (R6, R7)						
  storage.go:122		0x1001e20e8		b4000e06		CBZ R6, 112(PC)							
  vjp_elementwise.go:120	0x1001e20ec		d503201f		NOOP								
  storage.go:122		0x1001e20f0		a942a145		LDP 40(R10), (R5, R8)						
  storage.go:122		0x1001e20f4		b4000b25		CBZ R5, 89(PC)							
  tensor.go:121			0x1001e20f8		f9403be9		MOVD 112(RSP), R9						
  tensor.go:121			0x1001e20fc		f940012a		MOVD (R9), R10							
  vjp_elementwise.go:121	0x1001e2100		d503201f		NOOP								
  vjp_elementwise.go:121	0x1001e2104		d503201f		NOOP								
  storage.go:122		0x1001e2108		a942b14b		LDP 40(R10), (R11, R12)						
  storage.go:122		0x1001e210c		b40007eb		CBZ R11, 63(PC)							
  vjp_elementwise.go:122	0x1001e2110		aa1f03e3		MOVD ZR, R3							
  vjp_elementwise.go:122	0x1001e2114		f9402fe4		MOVD 88(RSP), R4						
  vjp_elementwise.go:122	0x1001e2118		14000016		JMP 22(PC)							
  vjp_elementwise.go:19		0x1001e211c		9000010a		ADRP 131072(PC), R10						
  vjp_elementwise.go:19		0x1001e2120		9133c14a		ADD $3312, R10, R10						
  vjp_elementwise.go:19		0x1001e2124		f0001d6b		ADRP 3862528(PC), R11						
  vjp_elementwise.go:19		0x1001e2128		9122c16b		ADD $2224, R11, R11						
  vjp_elementwise.go:19		0x1001e212c		a908afea		STP (R10, R11), 136(RSP)					
  vjp_elementwise.go:147	0x1001e2130		aa1f03e0		MOVD ZR, R0							
  vjp_elementwise.go:147	0x1001e2134		f9405be1		MOVD 176(RSP), R1						
  vjp_elementwise.go:147	0x1001e2138		f9405fe2		MOVD 184(RSP), R2						
  vjp_elementwise.go:147	0x1001e213c		f94063e3		MOVD 192(RSP), R3						
  vjp_elementwise.go:147	0x1001e2140		f94067e4		MOVD 200(RSP), R4						
  vjp_elementwise.go:147	0x1001e2144		f9406be5		MOVD 208(RSP), R5						
  vjp_elementwise.go:147	0x1001e2148		f9406fe6		MOVD 216(RSP), R6						
  vjp_elementwise.go:147	0x1001e214c		f94073e7		MOVD 224(RSP), R7						
  vjp_elementwise.go:147	0x1001e2150		f94077e8		MOVD 232(RSP), R8						
  vjp_elementwise.go:147	0x1001e2154		f9407be9		MOVD 240(RSP), R9						
  vjp_elementwise.go:147	0x1001e2158		910223fa		ADD $136, RSP, R26						
  vjp_elementwise.go:147	0x1001e215c		d63f0140		CALL (R10)							
  vjp_elementwise.go:142	0x1001e2160		f85f83fd		MOVD -8(RSP), R29						
  vjp_elementwise.go:142	0x1001e2164		f84a07fe		MOVD.P 160(RSP), R30						
  vjp_elementwise.go:142	0x1001e2168		d65f03c0		RET								
  vjp_elementwise.go:122	0x1001e216c		91000463		ADD $1, R3, R3							
  vjp_elementwise.go:122	0x1001e2170		eb03009f		CMP R3, R4							
  vjp_elementwise.go:122	0x1001e2174		540001ad		BLE 13(PC)							
  vjp_elementwise.go:123	0x1001e2178		eb07007f		CMP R7, R3							
  vjp_elementwise.go:123	0x1001e217c		54000442		BCS 34(PC)							
  vjp_elementwise.go:123	0x1001e2180		fc6378c0		FMOVD (R6)(R3<<3), F0						
  vjp_elementwise.go:123	0x1001e2184		1e602008		FCMPD $(0.0), F0						
  vjp_elementwise.go:123	0x1001e2188		54ffff2d		BLE -7(PC)							
  vjp_elementwise.go:124	0x1001e218c		eb08007f		CMP R8, R3							
  vjp_elementwise.go:124	0x1001e2190		54000382		BCS 28(PC)							
  vjp_elementwise.go:124	0x1001e2194		fc6378a0		FMOVD (R5)(R3<<3), F0						
  vjp_elementwise.go:124	0x1001e2198		eb0c007f		CMP R12, R3							
  vjp_elementwise.go:124	0x1001e219c		54000302		BCS 24(PC)							
  vjp_elementwise.go:124	0x1001e21a0		fc237960		FMOVD F0, (R11)(R3<<3)						
  vjp_elementwise.go:124	0x1001e21a4		17fffff2		JMP -14(PC)							
  vjp_elementwise.go:127	0x1001e21a8		b27d03e0		ORR $8, ZR, R0							
  vjp_elementwise.go:127	0x1001e21ac		f0001a81		ADRP 3485696(PC), R1						
  vjp_elementwise.go:127	0x1001e21b0		911da021		ADD $1896, R1, R1						
  vjp_elementwise.go:127	0x1001e21b4		b24003e2		ORR $1, ZR, R2							
  vjp_elementwise.go:127	0x1001e21b8		97f8e0b6		CALL runtime.mallocgcSmallScanNoHeaderSC1(SB)			
  vjp_elementwise.go:127	0x1001e21bc		d000201b		ADRP 4202496(PC), R27						
  vjp_elementwise.go:127	0x1001e21c0		b94bb363		MOVWU 2992(R27), R3						
  vjp_elementwise.go:127	0x1001e21c4		35000063		CBNZW R3, 3(PC)							
  vjp_elementwise.go:127	0x1001e21c8		f9403be5		MOVD 112(RSP), R5						
  vjp_elementwise.go:127	0x1001e21cc		14000004		JMP 4(PC)							
  vjp_elementwise.go:127	0x1001e21d0		97fa8dd8		CALL runtime.gcWriteBarrier1(SB)				
  vjp_elementwise.go:127	0x1001e21d4		f9403be5		MOVD 112(RSP), R5						
  vjp_elementwise.go:127	0x1001e21d8		f9000325		MOVD R5, (R25)							
  vjp_elementwise.go:127	0x1001e21dc		f9000005		MOVD R5, (R0)							
  vjp_elementwise.go:127	0x1001e21e0		b24003e1		ORR $1, ZR, R1							
  vjp_elementwise.go:127	0x1001e21e4		aa0103e2		MOVD R1, R2							
  vjp_elementwise.go:127	0x1001e21e8		aa1f03e3		MOVD ZR, R3							
  vjp_elementwise.go:127	0x1001e21ec		aa1f03e4		MOVD ZR, R4							
  vjp_elementwise.go:127	0x1001e21f0		f85f83fd		MOVD -8(RSP), R29						
  vjp_elementwise.go:127	0x1001e21f4		f84a07fe		MOVD.P 160(RSP), R30						
  vjp_elementwise.go:127	0x1001e21f8		d65f03c0		RET								
  vjp_elementwise.go:124	0x1001e21fc		97fa8e85		CALL runtime.panicBounds(SB)					
  vjp_elementwise.go:124	0x1001e2200		97fa8e84		CALL runtime.panicBounds(SB)					
  vjp_elementwise.go:123	0x1001e2204		97fa8e83		CALL runtime.panicBounds(SB)					
  storage.go:123		0x1001e2208		a907ffff		STP (ZR, ZR), 120(RSP)						
  storage.go:123		0x1001e220c		39400145		MOVBU (R10), R5							
  storage.go:123		0x1001e2210		b0000826		ADRP 1069056(PC), R6						
  storage.go:123		0x1001e2214		910e80c6		ADD $928, R6, R6						
  storage.go:123		0x1001e2218		8b050cc5		ADD R5<<3, R6, R5						
  storage.go:123		0x1001e221c		f0001c06		ADRP 3682304(PC), R6						
  storage.go:123		0x1001e2220		912500c6		ADD $2368, R6, R6						
  storage.go:123		0x1001e2224		a90797e6		STP (R6, R5), 120(RSP)						
  storage.go:123		0x1001e2228		90000760		ADRP 966656(PC), R0						
  storage.go:123		0x1001e222c		911ce000		ADD $1848, R0, R0						
  storage.go:123		0x1001e2230		d2800361		MOVD $27, R1							
  storage.go:123		0x1001e2234		9101e3e2		ADD $120, RSP, R2						
  storage.go:123		0x1001e2238		b24003e3		ORR $1, ZR, R3							
  storage.go:123		0x1001e223c		aa0303e4		MOVD R3, R4							
  storage.go:123		0x1001e2240		97fbabe0		CALL fmt.Sprintf(SB)						
  storage.go:123		0x1001e2244		97fa6acb		CALL runtime.convTstring(SB)					
  storage.go:123		0x1001e2248		aa0003e1		MOVD R0, R1							
  storage.go:123		0x1001e224c		f0001b60		ADRP 3600384(PC), R0						
  storage.go:123		0x1001e2250		9137e000		ADD $3576, R0, R0						
  storage.go:123		0x1001e2254		97fa71c7		CALL runtime.gopanic(SB)					
  storage.go:123		0x1001e2258		a907ffff		STP (ZR, ZR), 120(RSP)						
  storage.go:123		0x1001e225c		39400145		MOVBU (R10), R5							
  storage.go:123		0x1001e2260		b0000826		ADRP 1069056(PC), R6						
  storage.go:123		0x1001e2264		910e80c6		ADD $928, R6, R6						
  storage.go:123		0x1001e2268		8b050cc5		ADD R5<<3, R6, R5						
  storage.go:123		0x1001e226c		f0001c06		ADRP 3682304(PC), R6						
  storage.go:123		0x1001e2270		912500c6		ADD $2368, R6, R6						
  storage.go:123		0x1001e2274		a90797e6		STP (R6, R5), 120(RSP)						
  storage.go:123		0x1001e2278		90000760		ADRP 966656(PC), R0						
  storage.go:123		0x1001e227c		911ce000		ADD $1848, R0, R0						
  storage.go:123		0x1001e2280		d2800361		MOVD $27, R1							
  storage.go:123		0x1001e2284		9101e3e2		ADD $120, RSP, R2						
  storage.go:123		0x1001e2288		b24003e3		ORR $1, ZR, R3							
  storage.go:123		0x1001e228c		aa0303e4		MOVD R3, R4							
  storage.go:123		0x1001e2290		97fbabcc		CALL fmt.Sprintf(SB)						
  storage.go:123		0x1001e2294		97fa6ab7		CALL runtime.convTstring(SB)					
  storage.go:123		0x1001e2298		aa0003e1		MOVD R0, R1							
  storage.go:123		0x1001e229c		f0001b60		ADRP 3600384(PC), R0						
  storage.go:123		0x1001e22a0		9137e000		ADD $3576, R0, R0						
  storage.go:123		0x1001e22a4		97fa71b3		CALL runtime.gopanic(SB)					
  storage.go:123		0x1001e22a8		a907ffff		STP (ZR, ZR), 120(RSP)						
  storage.go:123		0x1001e22ac		394000a5		MOVBU (R5), R5							
  storage.go:123		0x1001e22b0		b0000826		ADRP 1069056(PC), R6						
  storage.go:123		0x1001e22b4		910e80c6		ADD $928, R6, R6						
  storage.go:123		0x1001e22b8		8b050cc5		ADD R5<<3, R6, R5						
  storage.go:123		0x1001e22bc		f0001c06		ADRP 3682304(PC), R6						
  storage.go:123		0x1001e22c0		912500c6		ADD $2368, R6, R6						
  storage.go:123		0x1001e22c4		a90797e6		STP (R6, R5), 120(RSP)						
  storage.go:123		0x1001e22c8		90000760		ADRP 966656(PC), R0						
  storage.go:123		0x1001e22cc		911ce000		ADD $1848, R0, R0						
  storage.go:123		0x1001e22d0		d2800361		MOVD $27, R1							
  storage.go:123		0x1001e22d4		9101e3e2		ADD $120, RSP, R2						
  storage.go:123		0x1001e22d8		b24003e3		ORR $1, ZR, R3							
  storage.go:123		0x1001e22dc		aa0303e4		MOVD R3, R4							
  storage.go:123		0x1001e22e0		97fbabb8		CALL fmt.Sprintf(SB)						
  storage.go:123		0x1001e22e4		97fa6aa3		CALL runtime.convTstring(SB)					
  storage.go:123		0x1001e22e8		aa0003e1		MOVD R0, R1							
  storage.go:123		0x1001e22ec		f0001b60		ADRP 3600384(PC), R0						
  storage.go:123		0x1001e22f0		9137e000		ADD $3576, R0, R0						
  storage.go:123		0x1001e22f4		97fa719f		CALL runtime.gopanic(SB)					
  vjp_elementwise.go:133	0x1001e22f8		91000463		ADD $1, R3, R3							
  vjp_elementwise.go:133	0x1001e22fc		eb03009f		CMP R3, R4							
  vjp_elementwise.go:133	0x1001e2300		540001ad		BLE 13(PC)							
  vjp_elementwise.go:134	0x1001e2304		eb07007f		CMP R7, R3							
  vjp_elementwise.go:134	0x1001e2308		54000442		BCS 34(PC)							
  vjp_elementwise.go:134	0x1001e230c		bc6378c0		FMOVS (R6)(R3<<2), F0						
  vjp_elementwise.go:134	0x1001e2310		1e202008		FCMPS $(0.0), F0						
  vjp_elementwise.go:134	0x1001e2314		54ffff2d		BLE -7(PC)							
  vjp_elementwise.go:135	0x1001e2318		eb08007f		CMP R8, R3							
  vjp_elementwise.go:135	0x1001e231c		54000382		BCS 28(PC)							
  vjp_elementwise.go:135	0x1001e2320		bc6378a0		FMOVS (R5)(R3<<2), F0						
  vjp_elementwise.go:135	0x1001e2324		eb0c007f		CMP R12, R3							
  vjp_elementwise.go:135	0x1001e2328		54000302		BCS 24(PC)							
  vjp_elementwise.go:135	0x1001e232c		bc237960		FMOVS F0, (R11)(R3<<2)						
  vjp_elementwise.go:135	0x1001e2330		17fffff2		JMP -14(PC)							
  vjp_elementwise.go:138	0x1001e2334		b27d03e0		ORR $8, ZR, R0							
  vjp_elementwise.go:138	0x1001e2338		f0001a81		ADRP 3485696(PC), R1						
  vjp_elementwise.go:138	0x1001e233c		911da021		ADD $1896, R1, R1						
  vjp_elementwise.go:138	0x1001e2340		b24003e2		ORR $1, ZR, R2							
  vjp_elementwise.go:138	0x1001e2344		97f8e053		CALL runtime.mallocgcSmallScanNoHeaderSC1(SB)			
  vjp_elementwise.go:138	0x1001e2348		d000201b		ADRP 4202496(PC), R27						
  vjp_elementwise.go:138	0x1001e234c		b94bb363		MOVWU 2992(R27), R3						
  vjp_elementwise.go:138	0x1001e2350		35000063		CBNZW R3, 3(PC)							
  vjp_elementwise.go:138	0x1001e2354		f9403be5		MOVD 112(RSP), R5						
  vjp_elementwise.go:138	0x1001e2358		14000004		JMP 4(PC)							
  vjp_elementwise.go:138	0x1001e235c		97fa8d75		CALL runtime.gcWriteBarrier1(SB)				
  vjp_elementwise.go:138	0x1001e2360		f9403be5		MOVD 112(RSP), R5						
  vjp_elementwise.go:138	0x1001e2364		f9000325		MOVD R5, (R25)							
  vjp_elementwise.go:138	0x1001e2368		f9000005		MOVD R5, (R0)							
  vjp_elementwise.go:138	0x1001e236c		b24003e1		ORR $1, ZR, R1							
  vjp_elementwise.go:138	0x1001e2370		aa0103e2		MOVD R1, R2							
  vjp_elementwise.go:138	0x1001e2374		aa1f03e3		MOVD ZR, R3							
  vjp_elementwise.go:138	0x1001e2378		aa1f03e4		MOVD ZR, R4							
  vjp_elementwise.go:138	0x1001e237c		f85f83fd		MOVD -8(RSP), R29						
  vjp_elementwise.go:138	0x1001e2380		f84a07fe		MOVD.P 160(RSP), R30						
  vjp_elementwise.go:138	0x1001e2384		d65f03c0		RET								
  vjp_elementwise.go:135	0x1001e2388		97fa8e22		CALL runtime.panicBounds(SB)					
  vjp_elementwise.go:135	0x1001e238c		97fa8e21		CALL runtime.panicBounds(SB)					
  vjp_elementwise.go:134	0x1001e2390		97fa8e20		CALL runtime.panicBounds(SB)					
  storage.go:115		0x1001e2394		a907ffff		STP (ZR, ZR), 120(RSP)						
  storage.go:115		0x1001e2398		39400145		MOVBU (R10), R5							
  storage.go:115		0x1001e239c		b0000826		ADRP 1069056(PC), R6						
  storage.go:115		0x1001e23a0		910e80c6		ADD $928, R6, R6						
  storage.go:115		0x1001e23a4		8b050cc5		ADD R5<<3, R6, R5						
  storage.go:115		0x1001e23a8		f0001c06		ADRP 3682304(PC), R6						
  storage.go:115		0x1001e23ac		912500c6		ADD $2368, R6, R6						
  storage.go:115		0x1001e23b0		a90797e6		STP (R6, R5), 120(RSP)						
  storage.go:115		0x1001e23b4		90000760		ADRP 966656(PC), R0						
  storage.go:115		0x1001e23b8		911d4c00		ADD $1875, R0, R0						
  storage.go:115		0x1001e23bc		d2800361		MOVD $27, R1							
  storage.go:115		0x1001e23c0		9101e3e2		ADD $120, RSP, R2						
  storage.go:115		0x1001e23c4		b24003e3		ORR $1, ZR, R3							
  storage.go:115		0x1001e23c8		aa0303e4		MOVD R3, R4							
  storage.go:115		0x1001e23cc		97fbab7d		CALL fmt.Sprintf(SB)						
  storage.go:115		0x1001e23d0		97fa6a68		CALL runtime.convTstring(SB)					
  storage.go:115		0x1001e23d4		aa0003e1		MOVD R0, R1							
  storage.go:115		0x1001e23d8		f0001b60		ADRP 3600384(PC), R0						
  storage.go:115		0x1001e23dc		9137e000		ADD $3576, R0, R0						
  storage.go:115		0x1001e23e0		97fa7164		CALL runtime.gopanic(SB)					
  storage.go:115		0x1001e23e4		a907ffff		STP (ZR, ZR), 120(RSP)						
  storage.go:115		0x1001e23e8		39400145		MOVBU (R10), R5							
  storage.go:115		0x1001e23ec		b0000826		ADRP 1069056(PC), R6						
  storage.go:115		0x1001e23f0		910e80c6		ADD $928, R6, R6						
  storage.go:115		0x1001e23f4		8b050cc5		ADD R5<<3, R6, R5						
  storage.go:115		0x1001e23f8		f0001c06		ADRP 3682304(PC), R6						
  storage.go:115		0x1001e23fc		912500c6		ADD $2368, R6, R6						
  storage.go:115		0x1001e2400		a90797e6		STP (R6, R5), 120(RSP)						
  storage.go:115		0x1001e2404		90000760		ADRP 966656(PC), R0						
  storage.go:115		0x1001e2408		911d4c00		ADD $1875, R0, R0						
  storage.go:115		0x1001e240c		d2800361		MOVD $27, R1							
  storage.go:115		0x1001e2410		9101e3e2		ADD $120, RSP, R2						
  storage.go:115		0x1001e2414		b24003e3		ORR $1, ZR, R3							
  storage.go:115		0x1001e2418		aa0303e4		MOVD R3, R4							
  storage.go:115		0x1001e241c		97fbab69		CALL fmt.Sprintf(SB)						
  storage.go:115		0x1001e2420		97fa6a54		CALL runtime.convTstring(SB)					
  storage.go:115		0x1001e2424		aa0003e1		MOVD R0, R1							
  storage.go:115		0x1001e2428		f0001b60		ADRP 3600384(PC), R0						
  storage.go:115		0x1001e242c		9137e000		ADD $3576, R0, R0						
  storage.go:115		0x1001e2430		97fa7150		CALL runtime.gopanic(SB)					
  storage.go:115		0x1001e2434		a907ffff		STP (ZR, ZR), 120(RSP)						
  storage.go:115		0x1001e2438		394000a5		MOVBU (R5), R5							
  storage.go:115		0x1001e243c		b0000826		ADRP 1069056(PC), R6						
  storage.go:115		0x1001e2440		910e80c6		ADD $928, R6, R6						
  storage.go:115		0x1001e2444		8b050cc5		ADD R5<<3, R6, R5						
  storage.go:115		0x1001e2448		f0001c06		ADRP 3682304(PC), R6						
  storage.go:115		0x1001e244c		912500c6		ADD $2368, R6, R6						
  storage.go:115		0x1001e2450		a90797e6		STP (R6, R5), 120(RSP)						
  storage.go:115		0x1001e2454		90000760		ADRP 966656(PC), R0						
  storage.go:115		0x1001e2458		911d4c00		ADD $1875, R0, R0						
  storage.go:115		0x1001e245c		d2800361		MOVD $27, R1							
  storage.go:115		0x1001e2460		9101e3e2		ADD $120, RSP, R2						
  storage.go:115		0x1001e2464		b24003e3		ORR $1, ZR, R3							
  storage.go:115		0x1001e2468		aa0303e4		MOVD R3, R4							
  storage.go:115		0x1001e246c		97fbab55		CALL fmt.Sprintf(SB)						
  storage.go:115		0x1001e2470		97fa6a40		CALL runtime.convTstring(SB)					
  storage.go:115		0x1001e2474		aa0003e1		MOVD R0, R1							
  storage.go:115		0x1001e2478		f0001b60		ADRP 3600384(PC), R0						
  storage.go:115		0x1001e247c		9137e000		ADD $3576, R0, R0						
  storage.go:115		0x1001e2480		97fa713c		CALL runtime.gopanic(SB)					
  vjp_elementwise.go:113	0x1001e2484		97fa8de3		CALL runtime.panicBounds(SB)					
  vjp_elementwise.go:113	0x1001e2488		d503201f		NOOP								
  vjp_elementwise.go:112	0x1001e248c		a90087e0		STP (R0, R1), 8(RSP)						
  vjp_elementwise.go:112	0x1001e2490		a9018fe2		STP (R2, R3), 24(RSP)						
  vjp_elementwise.go:112	0x1001e2494		a90297e4		STP (R4, R5), 40(RSP)						
  vjp_elementwise.go:112	0x1001e2498		a9039fe6		STP (R6, R7), 56(RSP)						
  vjp_elementwise.go:112	0x1001e249c		a904a7e8		STP (R8, R9), 72(RSP)						
  vjp_elementwise.go:112	0x1001e24a0		aa1e03e3		MOVD R30, R3							
  vjp_elementwise.go:112	0x1001e24a4		97fa8597		CALL runtime.morestack_noctxt.abi0(SB)				
  vjp_elementwise.go:112	0x1001e24a8		a94087e0		LDP 8(RSP), (R0, R1)						
  vjp_elementwise.go:112	0x1001e24ac		a9418fe2		LDP 24(RSP), (R2, R3)						
  vjp_elementwise.go:112	0x1001e24b0		a94297e4		LDP 40(RSP), (R4, R5)						
  vjp_elementwise.go:112	0x1001e24b4		a9439fe6		LDP 56(RSP), (R6, R7)						
  vjp_elementwise.go:112	0x1001e24b8		a944a7e8		LDP 72(RSP), (R8, R9)						
  vjp_elementwise.go:112	0x1001e24bc		17fffeb1		JMP github.com/jxsl13/goai/autograd.reluVJP(SB)			
